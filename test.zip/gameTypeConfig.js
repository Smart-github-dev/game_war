module.exports.UPDATE_KEY = "update";
module.exports.SEND_LEADERBORD = "leaderbord";
module.exports.SEND_ITEM = "items";
module.exports.SEND_ITEM_CHANGED = "items_change";
module.exports.FETCH_REQ = "fetch_req";
module.exports.FETCH_RES = "fetch_res";
module.exports.INPUT_CONTROL = "input";
module.exports.LOGIN = "login";
module.exports.NEW_PLAYER_GREATE = "new_player";
module.exports.SEND_MSG='msg'

