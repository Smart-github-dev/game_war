module.exports = {
    HOST: "localhost",
    PORT: 27017,
    DB: "war_plan",
};
